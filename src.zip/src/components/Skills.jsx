import React from 'react';

const Skills = () => {
  return (
    <div className="panel">
      <h2>Zdolności i umiejętności</h2>
      <ul>
        <li>JavaScript (React, Node.js)</li>
        <li>HTML & CSS (Sass, Bootstrap)</li>
        <li>Bazy danych (MySQL, MongoDB)</li>
        {/* Dodaj inne umiejętności */}
      </ul>
    </div>
  );
};

export default Skills;
