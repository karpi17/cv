import React from 'react';

const Education = () => <section><h2>Edukacja</h2></section>;

export default Education;