import React from 'react';

const Kariera = () => {
  return (
    <div className="panel">
      <h2>Kariera</h2>
      <ul>
        <li>Firma A – Junior Developer (2020-2021)</li>
        <li>Firma B – Mid Developer (2021-2023)</li>
        {/* Dodaj kolejne etapy kariery */}
      </ul>
    </div>
  );
};

export default Kariera;
