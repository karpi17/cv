import React from 'react';

const ThemeToggle = () => <button>Zmień motyw</button>;

export default ThemeToggle;