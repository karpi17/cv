import React from 'react';

const Dane = () => {
  return (
    <div className="panel">
      <h2>Dane Osobowe</h2>
      <p>Imię: Jan</p>
      <p>Nazwisko: Kowalski</p>
      <p>Data urodzenia: 01.01.1990</p>
      {/* Dodaj inne dane wg potrzeb */}
    </div>
  );
};

export default Dane;
