import React from 'react';

const Experience = () => <section><h2>Doświadczenie</h2></section>;

export default Experience;