export const data = {
    experience: [],
    education: [],
    skills: [],
    projects: []
};